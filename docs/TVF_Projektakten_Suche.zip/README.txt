Projektakten_Suche.xlsx öffnen → Alle_Projekte filtern → Auswahl gelbe Zelle.
Auch als Projektakte.xlsx nach SharePoint hochladen.
