Cockpit.xlsx – Werte aus D Finanzen/D KLR/D Liquidität übertragen.
Nach TVF-Controlling-Cockpit/Cockpit.xlsx HOCHLADEN UND ERSETZEN.
Seite veröffentlichen, dann Cmd+Shift+R.
