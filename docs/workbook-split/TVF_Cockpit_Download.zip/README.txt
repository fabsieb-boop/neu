Cockpit.xlsx = Hub mit eingebackenen Kennzahlen.
Nach TVF-Controlling-Cockpit/Cockpit.xlsx hochladen (ersetzen).
Seite veröffentlichen + Hard-Reload (Cmd+Shift+R).
Einzeldateien (Stunden, KLR, …) liegen in dateien/ bzw. TVF_Cockpit_Dateien.zip.
