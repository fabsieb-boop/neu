Alle Excel-Dateien mit eingebackenen Werten (kein #WERT! durch Verknüpfungen).
Hub als Cockpit.xlsx hochladen; restliche Dateien nach TVF-Controlling-Cockpit/.
