Alle Excel-Dateien mit eingebackenen Werten.
1) Cockpit.xlsx oder Cockpit-Hub-SharePoint.xlsx als Cockpit.xlsx hochladen
2) Inhalt von dateien/ nach TVF-Controlling-Cockpit/ hochladen (ersetzen)
3) Veröffentlichen + Hard-Reload
