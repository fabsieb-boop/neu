Cockpit.xlsx = Hub mit eingebackenen Kennzahlen (kein #WERT!).
Hochladen: Dokumente / TVF-Controlling-Cockpit / Cockpit.xlsx ersetzen.
Danach Seite veröffentlichen + Cmd+Shift+R.
Weitere Dateien (Stunden, KLR, …): TVF_Cockpit_Dateien.zip
