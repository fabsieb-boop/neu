Forecast je Auftrag.xlsx
Forecast Rechnung Abgleich.xlsx

Nach TVF-Controlling-Cockpit/ hochladen.
Quellen: D Finanzen (v_forecast_auftrag, v_forecast_monat).
